﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FastReportDings.Models.AmazonDeliveryNoteTest
{
    public class AmazonDeliveryNote
    {
        [Required] public string deliveryNoteNumber { get; set; }

        public string deliveryNoteNumberBarCode => $"S{deliveryNoteNumber}";

        [Required] public int packageNumber { get; set; }

        [Required] public int packageAmount { get; set; }

        [Required] public string shippingDetails { get; set; }

        [Required] public string shippiningOrigin { get; set; }

        [Required] public int shippingCenterNumber { get; set; }

        [Required] public DateTime orderDate { get; set; }

        [Required] public string orderNumber { get; set; }

        [Required] public DateTime deliveryNoteCreationDate { get; set; }

        public IEnumerable<Article> articles { get; set; }
    }

    public class Article
    {
        [Required] public int orderAmount { get; set; }

        [Required] public string articleDescription { get; set; }

        [Required] public string category { get; set; }

        public string categoryNumber { get; set; }
        public IEnumerable<string> asins { get; set; }
    }
}