﻿using System.Collections.Generic;
using System.IO;
using FastReport;
using FastReport.Data.JsonConnection;
using FastReport.Export.PdfSimple;
using FastReportDings.Models.AmazonDeliveryNoteTest;
using Newtonsoft.Json;

namespace FastReportDings.Controllers
{
    public class Samiclasse
    {
        public void NewMethod(AmazonDeliveryNote value)
        {
            var report = new Report();
            var pdfExport = new PDFSimpleExport();
            var gedoens = new List<AmazonDeliveryNote>();
            gedoens.Add(value);
            report.Load(@".\Reports\testreport.frx");
            report.RegisterData(gedoens, "JSON");
            var conn = (JsonDataSourceConnection) report.Dictionary.Connections[0];
            var conString = "Json='" + JsonConvert.SerializeObject(value) + @"';JsonSchema='" +
                            File.ReadAllText(@".\Reports\Schema.json") + "';Encoding=utf-8";
            conn.ConnectionString = conString;
            conn.CreateAllTables(false);
            report.Prepare();
            pdfExport.Export(report, @".\export.pdf");
        }
    }
}