﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using FastReport;
using FastReportDings.Models.MiniDelivery;

namespace FastReportDings.Controllers
{
    /// <summary>
    /// get the Json and packs it up in a Datatable
    /// Works with a flat structure of data
    ///
    /// Dirty part is the self parsing of a data object to a Datatable thought this could have been done
    /// in the usual parser itself. Might be good to invest why that is not working on there part  
    /// </summary>
    public class ReportTestClass
    {
        public void NewMethod(MiniDelivery minidelivery)
        {
            var report = new Report();
            byte[] bytes;
            var pdfExport = new FastReport.Export.Pdf.PDFExport();
            report.Load(@".\Reports\testreport.frx");
            report.RegisterData(ToDataTable(minidelivery.Positionen), "Positionen1");
            report.RegisterData(ToDataTable(minidelivery.Kopfdaten), "Kopfdaten");
            report.GetDataSource("Positionen1").Enabled = true;
            report.GetDataSource("Kopfdaten").Enabled = true;
            report.TextQuality = TextQuality.ClearType;
            report.Prepare();

            pdfExport.Export(report, @".\export.pdf");
        }

        /// <summary>
        /// Wraps the Json Array into a Dataset 
        /// </summary>
        /// <param name="data">Json data as IEnumerable</param>
        /// <typeparam name="T">>type of the object</typeparam>
        /// <returns>parsed DataTable</returns>
        private static DataTable ToDataTable<T>(IEnumerable<T> data)
        {
            var props = TypeDescriptor.GetProperties(typeof(T));
            var table = new DataTable();

            for (var i = 0; i < props.Count; i++)
            {
                var prop = props[i];
                table.Columns.Add(prop.Name, prop.PropertyType);
            }

            var values = new object[props.Count];
            foreach (var item in data)
            {
                for (var i = 0; i < values.Length; i++) values[i] = props[i].GetValue(item);
                table.Rows.Add(values);
            }

            return table;
        }
    }
}