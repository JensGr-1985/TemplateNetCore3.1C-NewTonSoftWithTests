﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FastReportDings.Models.MiniDelivery
{
    public class Positionen
    {
        public string Position { get; set; }
        public string Artikelnummer { get; set; }
        public string EANNummer { get; set; }
        public double Menge { get; set; }
        public string Bezeichnung1 { get; set; }
        public string Typ { get; set; }
        public string Mengeneinheit { get; set; }
    }

    public class Kopfdaten
    {
        public int BelID { get; set; }
        public int VorId { get; set; }
        public string Matchcode { get; set; }
        public int Empfaenger { get; set; }
        public string Versand { get; set; }
        public string Belegart { get; set; }
        public string Beleg { get; set; }
        public string BelegMiniLS { get; set; }
        public string Kundengruppe { get; set; }
        public string Kundengruppenname { get; set; }
        public string Kartonart { get; set; }
        public string LieferOrt { get; set; }
        public string LieferName { get; set; }
        public string LieferName2 { get; set; }
        public string LieferPLZ { get; set; }
        public string LieferLand { get; set; }
        public string LieferLandName { get; set; }
        public string LieferStrasse { get; set; }
        public bool istZoll { get; set; }
        public string Lieferbedingungen { get; set; }
        public string Bezug { get; set; }
        public string Belegkennzeichen { get; set; }
        public string Referenzzeichen { get; set; }
        public decimal Gewicht { get; set; }
    }

    public class MiniDelivery
    {
        public IList<Positionen> Positionen { get; set; }
        public IList<string> Infotexte { get; set; }
        public IList<Kopfdaten> Kopfdaten { get; set; }
        public IList<object> LabelDruckdokumente { get; set; }
        public IList<object> StandardDruckdokumente { get; set; }
    }
}