﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PdfCreation
{
    public class Kopfdaten
    {
        public string LieferscheinNr { get;set;}
        public DateTime LieferschienDatum { get;set;}
    }
}
