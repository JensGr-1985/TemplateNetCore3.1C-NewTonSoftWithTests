﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PdfCreation
{
    public class DeliveryNote
    {
        public string deliveryNoteNumber { get; set; }
        public string deliveryNoteNumberBarCode { get; set; }
        public int packageNumber { get; set; }
        public int packageAmount { get; set; }
        public string shippingDetails { get; set; }
        public string shippiningOrigin { get; set; }
        public int shippingCenterNumber { get; set; }
        public string orderDate { get; set; }
        public string orderNumber { get; set; }
        public string deliveryNoteCreationDate { get; set; }
    }
    public class Article
    {
        public int orderAmount { get; set; }
        public string articleDescription { get; set; }
        public string category { get; set; }
        public string categoryNumber { get; set; }
        public string asins { get; set; }
    }

    public class AmazonDeliveryNote
    {
        public List<DeliveryNote> DeliveryNote { get; set; }
        public List<Article> articles { get; set; }
    }
}
