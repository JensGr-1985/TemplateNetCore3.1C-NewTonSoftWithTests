﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PdfCreation.Models.SSCC
{
    public class SSCC
    {
     public AddressInformation Shipper { get; set; }
     public AddressInformation Reciever { get; set; }
        public string distributer { get; set; }
        public string purchaseOrders { get; set; }
        public string purchaseOrderBarCode { get; set; }
        public string upc2 { get; set; }
        public int qty { get; set; }
        public int currentShippmentBox { get; set; }
        public int shippmentBoxAmount { get; set; }
        public string ssccNr { get; set; }
    }

    public class AddressInformation
    {
        public string company { get; set; }
        public string companyLocation { get; set; }
        public string street { get; set; }
        public string city { get; set; }
        public string zipCode { get; set; }
        public string country { get; set; }
    }
}
