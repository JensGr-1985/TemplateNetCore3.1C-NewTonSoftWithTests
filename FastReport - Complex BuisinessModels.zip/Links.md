# Links
For the Product go to:
[Fastreport Homepage](https://www.fast-report.com/en/product/fast-report-net/?gclid=Cj0KCQiAk7TuBRDQARIsAMRrfUa7mtX6F_vnoNyh1A2E-0lo-N_WQFogysbO6cCxasjveGPsLLwyjhEaAqfZEALw_wcB)

For the Main Github Page go to: 
[Fastreport Main Github](https://github.com/FastReports)

For the Core Source go to:
[Fastreport Core Github](https://github.com/FastReports/FastReport)


For the Community Designer go to:
[Fastreport Releases Github](https://github.com/FastReports/FastReport/releases)
