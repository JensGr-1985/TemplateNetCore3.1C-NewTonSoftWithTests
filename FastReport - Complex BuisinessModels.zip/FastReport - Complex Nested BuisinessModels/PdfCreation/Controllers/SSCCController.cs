﻿using FastReport;
using FastReport.Export.PdfSimple;
using Microsoft.AspNetCore.Mvc;
using PdfCreation.Models.SSCC;
using System.Collections.Generic;

namespace PdfCreation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SSCCController : ControllerBase
    {
        [HttpPost]
        public void  Post(SSCC data)
        {
            PDFSimpleExport pdfExport = new PDFSimpleExport();
            var report = new Report();
            report.Load(@".\Reports\SSCC-json.frx");
            report.RegisterData(new List<SSCC>(){data}, "Kopfdaten");
            var temp = report.GetDataSource("Kopfdaten.purchaseOrders");
            report.Prepare();

            pdfExport.Export(report, @".\export.pdf");
            return;
        }
    }
}